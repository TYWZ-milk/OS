package com.example.elavator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by deii66 on 2017/4/27.
 */
public class Inner_elavator extends Activity {
    private ImageView back;
    private int count,start,end;
    private Handler mHandler = null;
    private TextView text;
    private boolean open =false;
    private boolean close =false;
    public Timer mTimer = null;
    public TimerTask mTimerTask = null;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inner_elavator);
        init();
        new Thread(new ThreadShow()).start();
    }
    public void init(){
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        count= bundle.getInt("position");
        start= bundle.getInt("start");
        end= bundle.getInt("end");

        back = (ImageView)findViewById(R.id.back);
        text = (TextView)findViewById(R.id.text);
        text.setText(Integer.toString(count));
    }
    public void back(View v) {
        finish();
    }
    public void open(View v) {
        open = true;
    }
    public void close(View v) {
        close = true;
    }
    // handler类接收数据
    Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                text.setText(Integer.toString(count++));
            }
        };
    };

    // 线程类
    class ThreadShow implements Runnable {

        @Override
        public void run() {
            while (count < end) {
                try {
                    if(count == start)
                        Thread.sleep(1000);
                    if(count == start && close == false)
                        Thread.sleep(3000);
                    Thread.sleep(1000);
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);
                } catch (Exception e) {
                }
            }
            if(count == end && open == false){
                try {
                    Thread.sleep(5000);  //电梯到达后停止5秒开门
                    finish();
                } catch (Exception e) {
                }
            }
            if(open == true && count == end){
                finish();
            }
        }
    }
}