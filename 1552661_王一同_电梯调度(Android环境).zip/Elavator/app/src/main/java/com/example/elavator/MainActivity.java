package com.example.elavator;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Window;
public class MainActivity extends Activity {
    private ArrayList<Elavator> elavators;
    private Elavator elavator1 = null;
    private Elavator elavator2 = null;
    private Elavator elavator3 = null;
    private Elavator elavator4 = null;
    private Elavator elavator5 = null;
    private static String  TAG = "TimerDemo";
    private TextView tv_start,tv_end;
    private Handler mHandler = null;
    private int up;
    public static MainActivity instance = null;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        elavators = new ArrayList<Elavator>();   //5部电梯
        elavator1 = new Elavator();
        elavator2 = new Elavator();
        elavator3 = new Elavator();
        elavator4 = new Elavator();
        elavator5 = new Elavator();

        elavators.add(elavator1);
        elavators.add(elavator2);
        elavators.add(elavator3);
        elavators.add(elavator4);
        elavators.add(elavator5);

        elavator1.UPDATE_TEXTVIEW=0;  //不同电梯更新信号不同
        elavator2.UPDATE_TEXTVIEW=1;
        elavator3.UPDATE_TEXTVIEW=2;
        elavator4.UPDATE_TEXTVIEW=3;
        elavator5.UPDATE_TEXTVIEW=4;

        tv_start = (TextView)findViewById(R.id.tv_start);
        tv_end = (TextView)findViewById(R.id.tv_end);
        elavator1.number = (TextView)findViewById(R.id.mytextview);//电梯楼层
        elavator2.number = (TextView)findViewById(R.id.text2);
        elavator3.number = (TextView)findViewById(R.id.text3);
        elavator4.number = (TextView)findViewById(R.id.text4);
        elavator5.number = (TextView)findViewById(R.id.text5);

        instance = this;

        mHandler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {   //更新不同电梯的楼层数
                    case 0:
                        elavator1.updateTextView();
                        break;
                    case 1:
                        elavator2.updateTextView();
                        break;
                    case 2:
                        elavator3.updateTextView();
                        break;
                    case 3:
                        elavator4.updateTextView();
                        break;
                    case 4:
                        elavator5.updateTextView();
                        break;
                    default:
                        break;
                }
            }
        };
    }
    public void Up(View v) {
        if (tv_start.getText().toString().equals("")||tv_end.getText().toString().equals("")) { //容错处理
            Toast.makeText(MainActivity.this, "请输入您所在位置", Toast.LENGTH_SHORT).show();
        } else {
            int []distance={100,100,100,100,100};  //5个电梯与起始点的距离
            int start = Integer.parseInt(tv_start.getText().toString()); //得到起点与终点
            int end =  Integer.parseInt(tv_end.getText().toString());
            if ( start > end ) {   //判断乘客是要上行还是下行
                up = -1;
            }
            if (start < end) {
                up = 1;
            }
            for(int i =0;i < elavators.size();i++) {    //寻找同向电梯
                if (elavators.get(i).up == up && up == 1 && elavators.get(i).count <start)
                    distance[i] = start - elavators.get(i).count;
                if(elavators.get(i).up == up && up == -1 && elavators.get(i).count >start)
                    distance[i] = elavators.get(i).count - start;
            }
            int temp = distance[0];
            int choice = -1;
            for(int i = 0;i < elavators.size(); i++){//得到最近的同向电梯距离 其余均为100
                    if(distance[i] <= temp && temp!=100) {
                        temp = distance[i];
                        choice = i;
                    }
                }
            if(choice == -1) {//无同向电梯 寻找最近距离空闲电梯
                for (int i = 0; i < elavators.size(); i++) {
                    if (elavators.get(i).isStop == true) {
                        distance[i] =  java.lang.Math.abs(elavators.get(i).count - start);
                    }
                    if(distance[i]<temp) {
                        temp = distance[i];
                        choice = i;
                    }
                }
            }
            if(choice == -1){  //操作过快
                Toast.makeText(MainActivity.this, "电梯繁忙，请稍后再试", Toast.LENGTH_SHORT).show();
            }
            else {
                if (elavators.get(choice).isStop) {//空闲状态
                    elavators.get(choice).Judge(start, end);
                    elavators.get(choice).startTimer();
                } else {//运行状态
                    elavators.get(choice).isAdd = true;
                    elavators.get(choice).midStart.add(start);
                    elavators.get(choice).midEnd.add(end);
                }
            }
        }
    }

    public void sendMessage(int id){
        if (mHandler != null) {
            Message message = Message.obtain(mHandler, id);
            mHandler.sendMessage(message);
        }
    }
}
