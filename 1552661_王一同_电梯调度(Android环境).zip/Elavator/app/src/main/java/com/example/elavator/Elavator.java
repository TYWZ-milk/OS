package com.example.elavator;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.content.Intent;
import android.widget.TextView;
/**
 * Created by deii66 on 2017/4/19.
 */
public class Elavator {
    public Timer mTimer = null;
    public TimerTask mTimerTask = null;
    public int count = 1;  //目前电梯位置
    public int end = 0;//终点
    public int start = 1;//起点
    public int UPDATE_TEXTVIEW;//数码显示器更新信号
    public int up = 0;//目前运行方向，0代表不运行，-1代表向下，1代表向上
    public boolean isStop = true;//电梯是否处于停止状态
    public boolean isOrder = false;//电梯是否前往起始点
    public boolean isAdd = false;//电梯是否接受到目标楼层外的请求
    public TextView number;//数码显示器控件
    public ArrayList<Integer> midStart = new ArrayList<Integer>();//电梯运行过程中接受到其他楼层的起点和终点请求
    public ArrayList<Integer> midEnd = new ArrayList<Integer>();
    public void stopTimer() {   //停止电梯
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
        if (mTimerTask != null) {
            mTimerTask.cancel();
            mTimerTask = null;
        }
        up = 0;
    }

    public void updateTextView() {
        number.setText(String.valueOf(count));
    }

    public void Judge(int iStart, int iEnd) {  //判断电梯该往哪个方向去
        isStop = !isStop;
        if (isStop){
            stopTimer();
        }
        else{
            start = iStart;
            end = iEnd;
            if (start > count)
                up = 1;
            if (start < count)
                up = -1;
            isOrder = true;
        }
    }
    public void Pos_to_Start(){   //当前位置到起点
        if (count < start && up == 1) {
            count++;
        } else if (count > start && up == -1) {
            count--;
        } else {
            stopTimer();
            Intent intent = new Intent();
            Bundle bundle=new Bundle();
            bundle.putInt("position", count);
            bundle.putInt("start", start);
            bundle.putInt("end", end);
            intent.putExtras(bundle);
            intent.setClass(MainActivity.instance, Inner_elavator.class);
            MainActivity.instance.startActivity(intent);
            try {
                isStop = true; //电梯到达停止点 停止5秒
                Thread.sleep(5000);
                isStop = false;
            } catch (InterruptedException e) {
            }
            isOrder = false;
            if (count < end)
                up = 1;
            if (count > end)
                up = -1;
        }
    }
    public void Start_to_End(){   //起点到终点
        if (count < end && up == 1) {    //电梯开始运行
            count++;
        } else if (count > end && up == -1) {
            count--;
        } else if (midEnd.size()!=0 && count >= end && up==1){
            if(count==end){
                try {
                    isStop = true; //电梯到达停止点 停止5秒
                    Thread.sleep(5000);
                    isStop = false;
                } catch (InterruptedException e) {
                }
            }
            for (int i = 0; i<midEnd.size(); i++) {
                if(midEnd.size()>0 && midEnd.size()!=i && end < midEnd.get(i)){
                    Add();
                    count++;
                }
            }
        } else if (midEnd.size()!=0 && count <= end && up==-1){
            if(count==end){
                try {
                    isStop = true;
                    Thread.sleep(5000);
                    isStop = false;
                } catch (InterruptedException e) {
                }
            }
            for (int i = 0; i<midEnd.size(); i++) {
                if(midEnd.size()>0 && midEnd.size()!=i && end > midEnd.get(i)){
                    Add();
                    count--;
                }
            }
        }
        else {
            stopTimer();
            isStop = true;
        }
    }
    public void Add(){   //同向楼层发出请求
        for (int i = 0; i < midStart.size()||i<midEnd.size(); i++) {
            if (midStart.size()>0 && midStart.size()!=i && count == midStart.get(i)) {
                try {
                    isStop = true;
                    Intent intent = new Intent();
                    Bundle bundle=new Bundle();
                    bundle.putInt("position", count);
                    bundle.putInt("start", midStart.get(i));
                    bundle.putInt("end", midEnd.get(i));
                    intent.putExtras(bundle);
                    intent.setClass(MainActivity.instance, Inner_elavator.class);
                    MainActivity.instance.startActivity(intent);
                    Thread.sleep(4000);
                    isStop = false;
                    midStart.remove(midStart.get(i));
                    if(midStart.size()==0&&midEnd.size()==0)
                        isAdd = false;
                } catch (InterruptedException e) {
                }
            }
            if (midEnd.size()>0 && midEnd.size()!=i && count == midEnd.get(i)) {
                try {
                    isStop = true;
                    Thread.sleep(5000);
                    isStop = false;
                    midEnd.remove(midEnd.get(i));
                    if(midStart.size()==0&&midEnd.size()==0)
                        isAdd = false;
                } catch (InterruptedException e) {
                }
            }
        }
    }
    public void startTimer(){//调用该电梯
        if (mTimer == null) {
            mTimer = new Timer();
        }

        if (mTimerTask == null) {
            mTimerTask = new TimerTask() {
                @Override
                public void run() {
                    if (isStop == false) {
                        MainActivity.instance.sendMessage(UPDATE_TEXTVIEW);

                        if(isAdd ==true){
                            if(up==up&&up==-1) {    //同时下降
                                Add();
                            }
                            if(up==up&&up==1) {    //同时上升
                                Add();
                            }
                        }
                        if (isOrder == true) {  //前往目标地点
                            Pos_to_Start();
                            if(count == start && isOrder == false) //到达起点
                                startTimer();
                        } else {                //起点到终点
                            Start_to_End();
                        }
                    }
                }
            };
        }

        if(mTimer != null && mTimerTask != null )
            mTimer.schedule(mTimerTask, 1000, 1000);
    }
}
