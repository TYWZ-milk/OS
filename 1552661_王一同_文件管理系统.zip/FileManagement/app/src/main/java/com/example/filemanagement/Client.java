package com.example.filemanagement;

import java.text.MessageFormat;

/**
 * 位示图法存储数据，面对大数据的时候可以减少内存的使用
 * @author lyq
 *
 */
public class Client {
    //声明了整形数组，最大的存放的数字的值可以到3 * 32
    private static int[] bitmap = new int[3];

    public static void main(String[] agrs){
        //  int[] initArray = new int[]{2, 15, 33, 75, 178, 1000};
        int[] initArray = new int[]{15, 31, 75};
        for (int anInitArray : initArray) {
            setBitmapNumber(anInitArray);
        }

        for (int i = 0; i < initArray.length; i++) {
            setIntToBit(bitmap[i]);
        }

        getBitmapNumber();
    }

    /**
     * 传入的数字，用来存储在位图中
     * @param number
     */
    public static void setBitmapNumber(int number){
        int index = number / 32;
        int pos = number % 32;
        int flag = 1;

        //如果刚好整除
        if(pos == 0){
            //算上个整数位的
            pos = 32;
            index--;
        }

        for(int j=0; j<pos-1; j++){
            //左移pos个位置，用于后面的位运算
            flag = flag << 1;
        }

        //找到此数组的位置，进行或运算，把此位置的0变为1
        bitmap[index] = bitmap[index] | flag;
        System.out.println(MessageFormat.format("第{0}下标，第{1}位，值为{2}", index, pos, bitmap[index]));
    }

    /**
     * 获取位图中所存放的数字
     */
    private static void getBitmapNumber(){
        int temp = 0;
        //在单个数字中的位偏移量
        int offset = 1;
        int flag = 1;

        for(int i=0; i<bitmap.length; i++){
            temp = bitmap[i];

            for(int j=0; j<31; j++){
                if((temp & flag) == 1){
                    //说明最右边一位为1
                    System.out.println(MessageFormat.format("第{0}下标，第{1}位，值为{2}", i, offset, 32 * i + offset));
                }

                temp = temp >> 1;
                offset++;
            }
            //重置偏移量为1
            offset = 1;
        }
    }

    /**
     * 整数表示成二进制位的形式
     * @param number
     */
    public static void setIntToBit(int number){
        int flag = 1;
        for(int j=0; j<31; j++){
            if((number & flag) == 1){
                //说明最右边一位为1
                System.out.print(1);
            }else{
                System.out.print(0);
            }
            number = number >> 1;
        }

        System.out.print("\n");
    }

}