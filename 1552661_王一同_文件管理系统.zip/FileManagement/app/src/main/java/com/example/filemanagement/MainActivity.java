package com.example.filemanagement;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.support.v7.app.ActionBarActivity;
import android.text.format.Formatter;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.AdapterView;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.text.SimpleDateFormat;

public class MainActivity extends ActionBarActivity {
    private boolean obtain_space = false;
    public MyAdapter adapter;
    public ListView listview;
    public String name;
    public FCB current_node = null;
    public FCB parent_node = new FCB();
    public FCB copy_node = new FCB();
    public boolean change;
    public TextView catalog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
        adapter = new MyAdapter(this);
        catalog= (TextView) findViewById(R.id.address);
        listview = (ListView) findViewById(R.id.listview);
        listview.setAdapter(adapter);
        if(obtain_space) {
            getAvailableInternalMemorySize(this);
            current_node.FAT(0,0);
        }
        try {
            read_Data();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }

        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView newadapter, View view, final int position, long id) {
                final String[] items = {"复制", "粘贴", "属性", "删除"};
                AlertDialog.Builder listDialog =
                        new AlertDialog.Builder(MainActivity.this);
                listDialog.setTitle("请选择操作");
                listDialog.setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {  //复制操作
                            copy_node = adapter.arr.get(position);
                        }
                        if (which == 1) { //粘贴操作
                            name = copy_node.name;
                            boolean same_name = false;
                            for (int i = 0; i < adapter.arr.size(); i++) {
                                if (adapter.arr.get(i).name.equals(name)) {
                                    same_name = true;
                                    copy_node.same_name++;
                                }
                            }
                            if (copy_node.fold) { //粘贴的是文件
                                SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd    hh:mm:ss");
                                String date = sDateFormat.format(new java.util.Date());
                                FCB file;
                                if (!same_name) {
                                    file = new FCB(true, name, date);
                                } else {
                                    file = new FCB(true, name + "(" + copy_node.same_name + ")", date);
                                }
                                adapter.arr.add(file);
                                change = true;
                                adapter.notifyDataSetChanged();
                            } else { //粘贴的是文件夹
                                SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd    hh:mm:ss");
                                String date = sDateFormat.format(new java.util.Date());
                                FCB folder;
                                if (!same_name) {
                                    folder = new FCB(false, name, date);
                                } else {
                                    folder = new FCB(false, name + "(" + copy_node.same_name + ")", date);
                                }
                                adapter.arr.add(folder);
                                change = true;
                                adapter.notifyDataSetChanged();
                            }
                        }
                        if (which == 2) { //查看属性
                            String fold = "文本文件";
                            if (adapter.arr.get(position).content != null)
                                adapter.arr.get(position).size = adapter.arr.get(position).content.length();
                            if (!adapter.arr.get(position).fold) {
                                adapter.arr.get(position).size = adapter.arr.get(position).child_list.size();
                                fold = "文件夹";
                            }
                            AlertDialog.Builder dlg = new AlertDialog.Builder(MainActivity.this);
                            dlg.setTitle("文件属性");
                            dlg.setMessage("文件名: " + adapter.arr.get(position).name + "\n" + "文件类型: " + fold + "\n" + "文件大小: " + adapter.arr.get(position).size + "B" + "\n" + "创建日期: " + adapter.arr.get(position).date+ "\n"+ "文件位置: " + catalog.getText());
                            dlg.setPositiveButton("确定", null);
                            dlg.create().show();

                        }
                        if (which == 3) {//删除
                            adapter.arr.get(position).delete = true;
                            adapter.arr.remove(position);
                            adapter.notifyDataSetChanged();
                        }
                    }
                });
                listDialog.show();
                return true;
            }
        });
        Button format = (Button) findViewById(R.id.format);
        format.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this).setTitle("系统提示")//设置对话框标题
                        .setMessage("是否格式化磁盘？")//设置显示的内容
                        .setPositiveButton("是", new DialogInterface.OnClickListener() {//添加确定按钮
                            @Override
                            public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                                name = null;
                                current_node = null;
                                parent_node = new FCB();
                                copy_node = new FCB();
                                change = false;
                                catalog.setText(":");
                                listview.setAdapter(null);
                                adapter.arr = new ArrayList<FCB>();
                                adapter = new MyAdapter(MainActivity.this);
                                listview.setAdapter(adapter);
                                adapter.notifyDataSetChanged();
                            }
                        }).setNegativeButton("取消", new DialogInterface.OnClickListener() {//添加返回按钮
                        @Override
                        public void onClick(DialogInterface dialog, int which) {//响应事件
                        }
                }).show();//在按键响应事件中显示此对话
            }
        });
        ImageView cancle = (ImageView) findViewById(R.id.iv_cancle);
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    write_data();
                } catch (Throwable throwable) {
                    throwable.printStackTrace();
                }
                finish();
            }
        });
        ImageView back = (ImageView) findViewById(R.id.iv_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (parent_node.name.equals("root")) {
                    Toast.makeText(MainActivity.this, "目前已在文件目录最高层", Toast.LENGTH_SHORT).show();
                } else {
                    save();

                    String address =catalog.getText().toString();
                    address=address.substring(0, address.lastIndexOf("\\"));
                    catalog.setText(address);
                    parent_node = parent_node.root;
                    current_node = null;
                    change = false;
                    listview.setAdapter(null);
                    adapter.arr = new ArrayList<FCB>();
                    adapter = new MyAdapter(MainActivity.this);
                    listview.setAdapter(adapter);

                    for (int i = 0; i < parent_node.child_list.size(); i++) {    //下一级内容赋值
                        adapter.arr.add(parent_node.child_list.get(i));
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        });
        ImageView add = (ImageView) findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this).setTitle("系统提示")//设置对话框标题
                        .setMessage("请选择新建文件或文件夹")//设置显示的内容
                        .setPositiveButton("文件", new DialogInterface.OnClickListener() {//添加确定按钮
                            @Override
                            public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                                final EditText edittext = new EditText(MainActivity.this);
                                new AlertDialog.Builder(MainActivity.this).setTitle("请输入文件名")//设置对话框标题
                                        .setIcon(android.R.drawable.ic_dialog_info)
                                        .setView(edittext)
                                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {//添加确定按钮
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件)
                                                name = edittext.getText().toString();
                                                boolean same_name = false;
                                                for (int i = 0; i < adapter.arr.size(); i++) {
                                                    if (adapter.arr.get(i).name.equals(name) && adapter.arr.get(i).fold) {
                                                        same_name = true;
                                                    }
                                                }
                                                if (same_name)
                                                    Toast.makeText(MainActivity.this, "已存在名为 " + name + " 的文件", Toast.LENGTH_SHORT).show();
                                                else if (name.equals(""))
                                                    Toast.makeText(MainActivity.this, "文件名不能为空", Toast.LENGTH_SHORT).show();
                                                else {
                                                    SimpleDateFormat sDateFormat  = new SimpleDateFormat("yyyy-MM-dd    hh:mm:ss");
                                                    String date = sDateFormat.format(new java.util.Date());
                                                    FCB file = new FCB(true, name,date);
                                                    adapter.arr.add(file);
                                                    change = true;
                                                    adapter.notifyDataSetChanged();
                                                }
                                            }
                                        }).setNegativeButton("取消", new DialogInterface.OnClickListener() {//添加返回按钮
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {//响应事件
                                    }
                                }).show();//在按键响应事件中显示此对话
                            }
                        }).setNegativeButton("文件夹", new DialogInterface.OnClickListener() {//添加返回按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//响应事件
                        final EditText edittext = new EditText(MainActivity.this);
                        new AlertDialog.Builder(MainActivity.this).setTitle("请输入文件夹名")//设置对话框标题
                                .setIcon(android.R.drawable.ic_dialog_info)
                                .setView(edittext)
                                .setPositiveButton("确定", new DialogInterface.OnClickListener() {//添加确定按钮
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                                        name = edittext.getText().toString();
                                        boolean same_name = false;
                                        for (int i = 0; i < adapter.arr.size(); i++) {
                                            if (adapter.arr.get(i).name.equals(name) && !adapter.arr.get(i).fold) {
                                                same_name = true;
                                            }
                                        }
                                        if (same_name)
                                            Toast.makeText(MainActivity.this, "已存在名为 " + name + " 的文件夹", Toast.LENGTH_SHORT).show();
                                        else if (name.equals(""))
                                            Toast.makeText(MainActivity.this, "文件夹名不能为空", Toast.LENGTH_SHORT).show();
                                        else {
                                            SimpleDateFormat sDateFormat  = new SimpleDateFormat("yyyy-MM-dd    hh:mm:ss");
                                            String date = sDateFormat.format(new java.util.Date());
                                            FCB folder = new FCB(false, name,date);
                                            adapter.arr.add(folder);
                                            change = true;
                                            adapter.notifyDataSetChanged();
                                        }
                                    }
                                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {//添加返回按钮
                            @Override
                            public void onClick(DialogInterface dialog, int which) {//响应事件
                            }
                        }).show();//在按键响应事件中显示此对话
                    }
                }).show();//在按键响应事件中显示此对话
            }
        });
    }
    /**
     * 获取手机内部可用存储空间
     *
     * @param context
     * @return 以M,G为单位的容量
     */
    public static String getAvailableInternalMemorySize(Context context) {
        File file = Environment.getDataDirectory();
        StatFs statFs = new StatFs(file.getPath());
        long availableBlocksLong = statFs.getAvailableBlocksLong();
        long blockSizeLong = statFs.getBlockSizeLong();
        return Formatter.formatFileSize(context, availableBlocksLong
                * blockSizeLong);
    }
    public void save(){
        if (parent_node.child_list.size() != 0) {
            current_node = parent_node.child_list.get(parent_node.child_list.size() - 1);
        }
        for (int i = 0; i < adapter.arr.size() && change; i++) {  //保存本级内容
            if (parent_node.child_list.size() == 0) {//第一次建立文件
                parent_node.child_list.add(adapter.arr.get(0));   //每次添加节点两个操作 将子节点与父节点建立双向连接
                current_node = adapter.arr.get(0);
                current_node.root = parent_node;
            }
            if (!current_node.find(adapter.arr.get(i)) && parent_node.child_list.size() != 0) {
                current_node = current_node.addNode(adapter.arr.get(i), parent_node);
            }
        }
        parent_node.delete(adapter.arr);
    }
    public void write_data() throws Throwable
    {
        save();
        while(!parent_node.name.equals("root"))
            parent_node=parent_node.root;
        SharedPreferences sharedinfo = getSharedPreferences("content", Context.MODE_PRIVATE);
        SharedPreferences.Editor user_editor = sharedinfo.edit();//获取编辑器
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parent_node);
        String imageBase64 = new String(Base64.encode(baos.toByteArray(), Base64.DEFAULT));
        //保存转换后的Base64格式字符串
        user_editor.putString("image", imageBase64);
        user_editor.commit();
    }
    public void read_Data() throws Throwable
    {
        SharedPreferences sharedinfo = getSharedPreferences("content", Context.MODE_PRIVATE);
        byte[] mobileBytes = Base64.decode(sharedinfo.getString("image",null),Base64.DEFAULT);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(mobileBytes);
        ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
        parent_node = (FCB) objectInputStream.readObject();
        objectInputStream.close();
        if(parent_node.child_list.size()!=0) {
            for (int i = 0; i < parent_node.child_list.size(); i++) {
                adapter.arr.add(parent_node.child_list.get(i));
            }
        }
    }
    public class MyAdapter extends BaseAdapter {

        private LayoutInflater inflater;
        public View missionView;
        public ArrayList<FCB> arr;
        public MyAdapter(Context context) {
            super();
            inflater = LayoutInflater.from(context);
            arr = new ArrayList<FCB>();
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return arr.size();
        }

        @Override
        public Object getItem(int arg0) {
            // TODO Auto-generated method stub
            return arg0;
        }

        @Override
        public long getItemId(int arg0) {
            // TODO Auto-generated method stub
            return arg0;
        }

        @Override
        public View getView(final int position, View view, ViewGroup arg2) {
            ViewHolder holder=null;
            if (view == null) {
                holder = new ViewHolder();
                view = inflater.inflate(R.layout.folder_item, null);
                holder.name = (TextView) view.findViewById(R.id.name);
                holder.image = (ImageView) view.findViewById(R.id.folder);
                view.setTag(holder);

            }else
            {
                holder = (ViewHolder)view.getTag();
                missionView=view;
            }
            if(arr.get(position).fold){
                holder.image.setImageResource(R.drawable.fold);
                holder.name.setText(arr.get(position).name);
            }
            if(!arr.get(position).fold){
                holder.image.setImageResource(R.drawable.folder);
                holder.name.setText(arr.get(position).name);
            }
            holder.image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    if (!arr.get(position).fold) {
                        save();
                        parent_node = adapter.arr.get(position);
                        current_node = null;
                        change = false;
                        String address =catalog.getText().toString()+"\\"+ adapter.arr.get(position).name;
                        catalog.setText(address);
                        listview.setAdapter(null);
                        arr = new ArrayList<FCB>();
                        adapter = new MyAdapter(MainActivity.this);
                        listview.setAdapter(adapter);
                        for (int i = 0; i < parent_node.child_list.size(); i++) {    //下一级内容赋值
                            adapter.arr.add(parent_node.child_list.get(i));
                        }
                        adapter.notifyDataSetChanged();
                    } else {
                        final EditText edittext = new EditText(MainActivity.this);
                        new AlertDialog.Builder(MainActivity.this).setTitle(arr.get(position).content)//设置对话框标题
                                .setView(edittext)
                                .setPositiveButton("保存", new DialogInterface.OnClickListener() {//添加确定按钮
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                                        if (arr.get(position).content == null)
                                            arr.get(position).content = edittext.getText().toString();
                                        else
                                            arr.get(position).content += edittext.getText().toString();
                                    }
                                })
                                .setNeutralButton("重新保存", new DialogInterface.OnClickListener() {

                                    @Override
                                    public void onClick(DialogInterface arg0, int arg1) {
                                        arr.get(position).content = edittext.getText().toString();
                                    }
                                }).setNegativeButton("关闭", new DialogInterface.OnClickListener() {//添加返回按钮
                            @Override
                            public void onClick(DialogInterface dialog, int which) {//响应事件
                            }
                        }).show();//在按键响应事件中显示此对话
                    }
                }
            });
            return view;
        }
        class ViewHolder
        {
            ImageView image;
            TextView name;
        }

    }
}
