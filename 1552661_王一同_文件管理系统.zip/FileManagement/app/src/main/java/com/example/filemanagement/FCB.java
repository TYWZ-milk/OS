package com.example.filemanagement;

import java.io.Serializable;
import java.util.ArrayList;

public  class FCB implements Serializable {
    public String name; //文件名
    public int size;    //文件大小
    public boolean fold; //文件类型
    public String date; //创建日期
    public String content;//文本文件内容
    public FCB root;     //目录结构父节点
    public FCB left;    //目录结构左兄弟节点
    public FCB right;   //目录结构右兄弟节点
    public int current_level;//第几级目录结构
    public ArrayList<FCB> child_list;//该文件夹下文件
    public boolean delete = false;//删除标志
    public int same_name;  //同文件夹下同名的文件数
    private int start_address=0;  //显式链接中文件目录的起址
    private  int end_address=1;   //显示链接中文件目录的终址
    public void FAT(int start,int end){  //显示链接
        this.start_address = start;
        this.end_address = end;
        while(start_address<end_address) {
            start_address++;
        }
    }
    public FCB(boolean fold, String name,String date) { //创建文件
        this.current_level = 0;
        this.size = 0;
        this.fold = fold;
        this.name = name;
        this.content = "";
        this.child_list = new ArrayList<FCB>();
        this.date = date;
        this.same_name = 0;
    }
    public FCB() {  //创建根节点
        this.child_list = new ArrayList<FCB>();
        this.name = "root";
    }
    /**
     * 为指定节点添加子节点
     * @param brotherNode 添加的兄弟节点
     * @return 新增的节点
     */
    public FCB addNode(FCB brotherNode,FCB parentNode) {
        if (this.right != null) {
            throw new RuntimeException(this + "节点已有左子节点，不能添加左子节点！");
        }
        this.right = brotherNode;
        brotherNode.left = this;
        if(parentNode != null) {
            this.root = parentNode;
            brotherNode.root = parentNode;
            parentNode.child_list.add(brotherNode);
        }
        return brotherNode;
    }
    public boolean find(FCB fcb){
        boolean same = false;
        FCB temp = this.root.child_list.get(0);
        for(int i =0;i<this.root.child_list.size();i++) {
            if(temp==fcb) {
                same = true;
                break;
            }
            temp = temp.right;
        }
        return same;
    }

    public void delete(ArrayList<FCB> arr){  //删除节点
        for(int i =0;i<arr.size();i++){
            if(arr.get(i).delete){
                for(int j =0;j<this.child_list.size();j++) {
                    if(this.child_list.get(j) ==arr.get(i)) {
                        if(this.child_list.get(j).left!=null && this.child_list.get(j).right!=null){
                            this.child_list.get(j).right.left = this.child_list.get(j).left ;
                            this.child_list.get(j).left.right = this.child_list.get(j).right;
                        }
                        if(this.child_list.get(j).left==null && this.child_list.get(j).right!=null){
                            this.child_list.get(j).right.left= null;
                        }
                        if(this.child_list.get(j).left!=null && this.child_list.get(j).right==null){
                            this.child_list.get(j).left.right = null;
                        }
                        this.child_list.remove(j);
                        break;
                    }
                }
            }
        }
    }
}