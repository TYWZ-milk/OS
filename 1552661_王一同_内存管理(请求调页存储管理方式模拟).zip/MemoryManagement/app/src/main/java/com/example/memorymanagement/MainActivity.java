package com.example.memorymanagement;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.ArrayList;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
public class MainActivity extends ActionBarActivity {
    public boolean FIFO = false;  //是否执行FIFO算法
    public int point=0;  //两种算法中内存的指针
    public boolean LRU = false;   //是否执行LRU算法
    public boolean Random = true;  //是否执行Random算法
    public int current_instructions=0; //当前执行指令数
    static int total_instructions = 320; //作业指令总数
    private ListView listview;   //视图一
    public MyAdapter adapter;    //listview内容
    public Button start,auto_start,reset;        //逐步演示按钮和自动演示和复位按钮
    public int[] random_result;//随机指令执行顺序
    public ArrayList<Integer> main_memory;//内存页面
    public int number_loss_page = 0;        //失页次数
    public TextView tv_loss_page,loss_rate,page1,page2,page3,page4;  //缺页次数、缺页率、内存页面视图
    public boolean auto = true;      //是否为自动演示
    public RadioGroup algorithm,order;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listview = (ListView) findViewById(R.id.listView);
        start = (Button) findViewById(R.id.start);
        reset = (Button) findViewById(R.id.reset);
        auto_start = (Button) findViewById(R.id.auto_start);
        tv_loss_page = (TextView) findViewById(R.id.number_loss_page);
        loss_rate = (TextView) findViewById(R.id.loss_rate);
        page1 = (TextView) findViewById(R.id.page1);
        page2 = (TextView) findViewById(R.id.page2);
        page3 = (TextView) findViewById(R.id.page3);
        page4 = (TextView) findViewById(R.id.page4);
        algorithm = (RadioGroup) findViewById(R.id.algorithm);
        order = (RadioGroup) findViewById(R.id.order);

        adapter = new MyAdapter(this);
        main_memory = new ArrayList<Integer>();
        listview.setAdapter(adapter);

        algorithm.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup arg0, int arg1) {
                // TODO Auto-generated method stub
                //获取变更后的选中项的ID
                    int radioButtonId = arg0.getCheckedRadioButtonId();
                    if (radioButtonId == 2131492949) {
                        FIFO = true;
                        LRU = false;
                    }
                    if (radioButtonId == 2131492950) {
                        FIFO = false;
                        LRU = true;
                    }
            }
        });
        order.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup arg0, int arg1) {
                // TODO Auto-generated method stub
                //获取变更后的选中项的ID
                int radioButtonId = arg0.getCheckedRadioButtonId();
                if(radioButtonId == 2131492952){
                    random_result = randomArray(0,total_instructions,total_instructions);
                    Random = true;
                }
                if(radioButtonId == 2131492953){
                    second_random();
                    Random = false;
                }
            }
        });
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(FIFO == false && LRU == false){
                    Toast.makeText(MainActivity.this, "请选择置换算法", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (current_instructions < total_instructions) {
                        auto = false;
                        adapter.arr.add("new");
                        adapter.notifyDataSetChanged();
                        current_instructions++;
                    } else {
                        Toast.makeText(MainActivity.this, "本次演示已执行完", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        auto_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(FIFO == false && LRU == false){
                    Toast.makeText(MainActivity.this, "请选择置换算法", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (auto == true) {
                        for (int i = 0; i < 320; i++) {
                            adapter.arr.add("old");
                            adapter.notifyDataSetChanged();
                            current_instructions++;
                        }
                        autoshow();
                        Toast.makeText(MainActivity.this, "本次演示已执行完", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "逐步演示中无法自动演示", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                auto = true;
                page1.setText("无");
                page2.setText("无");
                page3.setText("无");
                page4.setText("无");
                tv_loss_page.setText("0");
                loss_rate.setText("0%");
                listview.setAdapter(null);
                current_instructions=0;
                point = 0;
                number_loss_page = 0;
                main_memory = new ArrayList<Integer>();
                if(Random == false) {
                    second_random();
                }
                else{
                    random_result = randomArray(0,total_instructions,total_instructions);
                }
                adapter =new MyAdapter(MainActivity.this);
                listview.setAdapter(adapter);
                Toast.makeText(MainActivity.this, "程序已复位", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void second_random(){
        int flag = 0;
        random_result = new int [320];
        Random rand = new Random();
        int randNum = rand.nextInt(320);
        for(int i=0; i<320; i++){
            random_result[i]=randNum;
            if(flag%2==0)
                randNum = ++randNum%320;
            if(flag==1)
                randNum = rand.nextInt(320)%(randNum-1);
            if(flag==3)
                randNum = randNum+1+(rand.nextInt(320)%(320-(randNum+1)));
            flag = ++flag%4;
        }
    }
    public void autoshow(){
        if(FIFO==true) {
            for (int i = 0; i < 320; i++) {
                int hundreds = random_result[i] / 100;
                int tens = (random_result[i] % 100) / 10;
                int page = tens + hundreds * 10;
                boolean loss = true;
                for (int j = 0; j < main_memory.size(); j++) {
                    if (main_memory.get(j) == page) {
                        loss = false;
                        break;
                    }
                }
                if (loss == true) {
                    number_loss_page++;
                    if (main_memory.size() < 4) {
                        main_memory.add(page);
                    } else {
                        main_memory.set(point, page);
                        point++;
                    }
                    if (point == 4)
                        point = 0;
                }
            }
            tv_loss_page.setText(String.valueOf(number_loss_page));
            float rate = (float) number_loss_page / current_instructions * 100;
            DecimalFormat df = new DecimalFormat("#.00");
            loss_rate.setText(df.format(rate) + "%");
        }
        if(LRU==true){
            number_loss_page = 0;
            for (int iX = 0; iX < 320; iX++) {
                int hundreds = random_result[iX] / 100;
                int tens = (random_result[iX] % 100) / 10;
                int page = tens + hundreds * 10;
                boolean loss = true;
                for (int i = 0; i < main_memory.size(); i++) {
                    if (main_memory.get(i) == page) {
                        loss = false;
                        break;
                    }
                }
                if (loss == true) {
                    number_loss_page++;
                    int position1 = 0, position2 = 0, position3 = 0, position4 = 0;
                    boolean bl_page1 = false, bl_page2 = false, bl_page3 = false, bl_page4 = false;
                    if (main_memory.size() < 4) {
                        main_memory.add(page);
                        point++;
                    } else {
                        for (int i = iX - 1; bl_page1 == false || bl_page2 == false || bl_page3 == false || bl_page4 == false; i--) {
                            int pre_hundreds = random_result[i] / 100;
                            int pre_tens = (random_result[i] % 100) / 10;
                            int pre_page = pre_tens + pre_hundreds * 10;
                            if (main_memory.get(0) == pre_page && bl_page1 == false) {
                                position1 = iX - i;
                                bl_page1 = true;
                            }
                            if (main_memory.get(1) == pre_page && bl_page2 == false) {
                                position2 = iX - i;
                                bl_page2 = true;
                            }
                            if (main_memory.get(2) == pre_page && bl_page3 == false) {
                                position3 = iX - i;
                                bl_page3 = true;
                            }
                            if (main_memory.get(3) == pre_page && bl_page4 == false) {
                                position4 = iX - i;
                                bl_page4 = true;
                            }
                        }
                        int[] total_position = {position1, position2, position3, position4};
                        int temp = total_position[0];
                        int lru_page = 0;
                        for (int i = 0; i < 3; i++) {
                            if (temp < total_position[i + 1]) {
                                temp = total_position[i + 1];
                                lru_page = i + 1;
                            }
                        }
                        point = lru_page;
                        main_memory.set(point, page);
                        point++;
                    }
                    if (point == 4)
                        point = 0;
                }
            }
            tv_loss_page.setText(String.valueOf(number_loss_page));
            float rate = (float) number_loss_page / current_instructions * 100;
            DecimalFormat df = new DecimalFormat("#.00");
            loss_rate.setText(df.format(rate) + "%");
        }
    }
    public static int[] randomArray(int min,int max,int n){
        int len = max-min+1;

        if(max < min || n > len){
            return null;
        }

        //初始化给定范围的待选数组
        int[] source = new int[len];
        for (int i = min; i < min+len; i++){
            source[i-min] = i;
        }

        int[] result = new int[n];
        Random rd = new Random();
        int index = 0;
        for (int i = 0; i < result.length; i++) {
            //待选数组0到(len-2)随机一个下标
            index = Math.abs(rd.nextInt() % len--);
            //将随机到的数放入结果集
            result[i] = source[index];
            //将待选数组中被随机到的数，用待选数组(len-1)下标对应的数替换
            source[index] = source[len];
        }
        return result;
    }
    private class MyAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater inflater;
        public ArrayList<String> arr;
        public Bitmap bitmap;
        public MyAdapter(Context context) {
            super();
            this.context = context;
            inflater = LayoutInflater.from(context);
            arr = new ArrayList<String>();
        }
        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return arr.size();
        }

        @Override
        public Object getItem(int arg0) {
            // TODO Auto-generated method stub
            return arg0;
        }

        @Override
        public long getItemId(int arg0) {
            // TODO Auto-generated method stub
            return arg0;
        }
        @Override
        public View getView(final int position, View view, ViewGroup arg2) {
            ViewHolder holder=null;
            // TODO Auto-generated method stub
            if (view == null) {
                holder = new ViewHolder();
                view = inflater.inflate(R.layout.listview_item, null);

                holder.order = (TextView) view.findViewById(R.id.order);
                holder.number = (TextView) view.findViewById(R.id.number);
                holder.page = (TextView) view.findViewById(R.id.page);
                view.setTag(holder);

            }else
            {
                holder = (ViewHolder)view.getTag();
            }
            holder.number.setText(String.valueOf(position+1));
            holder.order.setText(String.valueOf(random_result[position]));
            int hundreds = random_result[position]/100;
            int tens = (random_result[position]%100)/10;
            int page = tens+hundreds*10;
            holder.page.setText(String.valueOf(page));
            if(LRU == true){
                if (arr.get(position) == "new") {
                    boolean loss = true;
                    for (int i = 0; i < main_memory.size(); i++) {
                        if (main_memory.get(i) == page) {
                            loss = false;
                            break;
                        }
                    }
                    if (loss == true) {
                        number_loss_page++;
                        int position1=0,position2=0,position3=0,position4=0;
                        boolean bl_page1=false,bl_page2=false,bl_page3=false,bl_page4=false;
                        if (main_memory.size() < 4) {
                            main_memory.add(page);
                            if (point == 0)
                                page1.setText(String.valueOf(page));
                            if (point == 1)
                                page2.setText(String.valueOf(page));
                            if (point == 2)
                                page3.setText(String.valueOf(page));
                            if (point == 3)
                                page4.setText(String.valueOf(page));
                            point++;
                        } else {
                            for(int i=position-1;bl_page1==false || bl_page2==false || bl_page3==false || bl_page4==false;i--){
                                int pre_hundreds = random_result[i]/100;
                                int pre_tens = (random_result[i]%100)/10;
                                int pre_page = pre_tens+pre_hundreds*10;
                                if(main_memory.get(0)==pre_page && bl_page1 == false) {
                                    position1 =position - i;
                                    bl_page1 = true;
                                }
                                if(main_memory.get(1)==pre_page && bl_page2 == false){
                                    position2=position - i;
                                    bl_page2 = true;
                               }
                                if(main_memory.get(2)==pre_page && bl_page3 == false) {
                                    position3 = position - i;
                                    bl_page3 = true;
                                }
                                if(main_memory.get(3)==pre_page && bl_page4 == false) {
                                    position4 =position - i;
                                    bl_page4 = true;
                                }
                            }
                            int []total_position = {position1,position2,position3,position4};
                            int temp = total_position[0];
                            int lru_page = 0;
                            for(int i = 0; i<3 ; i++){
                                if(temp<total_position[i+1]) {
                                    temp = total_position[i+1];
                                    lru_page = i+1;
                                }
                            }
                            point = lru_page;
                            main_memory.set(point, page);
                            if (point == 0)
                                page1.setText(String.valueOf(page));
                            if (point == 1)
                                page2.setText(String.valueOf(page));
                            if (point == 2)
                                page3.setText(String.valueOf(page));
                            if (point == 3)
                                page4.setText(String.valueOf(page));
                            point++;
                        }
                        if (point == 4)
                            point = 0;
                    }
                    tv_loss_page.setText(String.valueOf(number_loss_page));
                    float rate = (float) number_loss_page / current_instructions * 100;
                    DecimalFormat df = new DecimalFormat("#.00");
                    loss_rate.setText(df.format(rate) + "%");
                    arr.set(position, "old");
                }
            }
            if(FIFO == true) {
                if (arr.get(position) == "new") {
                    boolean loss = true;
                    for (int i = 0; i < main_memory.size(); i++) {
                        if (main_memory.get(i) == page) {
                            loss = false;
                            break;
                        }
                    }
                    if (loss == true) {
                        number_loss_page++;
                        if (main_memory.size() < 4) {
                            main_memory.add(page);
                            if (point == 0)
                                page1.setText(String.valueOf(page));
                            if (point == 1)
                                page2.setText(String.valueOf(page));
                            if (point == 2)
                                page3.setText(String.valueOf(page));
                            if (point == 3)
                                page4.setText(String.valueOf(page));
                            point++;
                        } else {
                            main_memory.set(point, page);
                            if (point == 0)
                                page1.setText(String.valueOf(page));
                            if (point == 1)
                                page2.setText(String.valueOf(page));
                            if (point == 2)
                                page3.setText(String.valueOf(page));
                            if (point == 3)
                                page4.setText(String.valueOf(page));
                            point++;
                        }
                        if (point == 4)
                            point = 0;
                    }
                    tv_loss_page.setText(String.valueOf(number_loss_page));
                    float rate = (float) number_loss_page / current_instructions * 100;
                    DecimalFormat df = new DecimalFormat("#.00");
                    loss_rate.setText(df.format(rate) + "%");
                    arr.set(position, "old");
                }
            }
            return view;
        }
        class ViewHolder
        {
            TextView order,number,page;
        }

    }
}
